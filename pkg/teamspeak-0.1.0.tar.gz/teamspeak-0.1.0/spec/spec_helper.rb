require 'rubygems'
require 'spec'
require File.dirname(__FILE__) + '/../lib/teamspeak'

Teamspeak.config = {
	:host => 'ts.aesyr.com',
	:user => 'serveradmin',
	:password => 'YyQR7bdo'		
}
