require 'lib/teamspeak'

Teamspeak.config = {
	:host => 'ts.aesyr.com',
	:user => 'serveradmin',
	:password => 'YyQR7bdo'		
}

# Teamspeak.gm('Fantastoidisch! Beta 9..')
# exit

puts Teamspeak.servers.inspect
exit

ts = Teamspeak::Server.find(1)
puts ts.inspect
# puts ts.clients.inspect

puts "-----------------\n\n"
ts.clients.each {|c|
	puts "\tClient: #{c.nickname}\n"
	puts c.inspect
	puts "\n"

	if c.nickname == 'fyrn'
		# c.message('FUCK YOU OIDA')
		c.client_is_talker = false
	end
}
puts "-----------------\n\n"
