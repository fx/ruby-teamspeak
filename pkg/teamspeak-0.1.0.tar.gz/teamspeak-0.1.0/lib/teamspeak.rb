require 'socket'
include Socket::Constants

module Teamspeak
	TEXTMESSAGETARGET_CLIENT = 1
	TEXTMESSAGETARGET_CHANNEL = 2
	TEXTMESSAGETARGET_SERVER = 3

	class Client
		attr_accessor :attributes, :server

		def initialize(attr = {})
			@attributes = attr

			attr.each {|attribute, value|
				instance_variable_set("@#{attribute}", value.to_i.to_s == value ? value.to_i : value)

				self.class.class_eval <<-EOF
					def #{attribute}
						instance_variable_get("@#{attribute}")
					end
				EOF
			}
		end

		def cmd(command, *attributes)
			server.cmd(command, attributes[0])
		end

		def message(msg = '')
			cmd(:sendtextmessage, :targetmode => TEXTMESSAGETARGET_CLIENT, :target => clid, :msg => msg)
		end

		# def method_missing(method, *args)
		# end

		# custom get/set for values that can be changed on the server as well
		def talker=(value)
			client_is_talker = value
		end
		
		def talker
			client_is_talker
		end

		def client_is_talker=(value)
			# return false if ![true, false].include?(value)
			cmd(:clientedit, :clid => clid, :client_is_talker => value ? 1 : 0)
			@client_is_talker = value
		end
		
		def client_is_talker
			@client_is_talker
		end

		class << self
			def find(*args)
			end
		end
	end

	class Server
		attr_accessor :attributes

		def initialize(attr = {})
			@attributes = attr

			attr.each {|attribute, value|
				instance_variable_set("@#{attribute}", value.to_i.to_s == value ? value.to_i : value)

				self.class.class_eval <<-EOF
					def #{attribute}
						instance_variable_get("@#{attribute}")
					end
				EOF
			}
		end

		def socket
			Teamspeak.socket
		end
		
		def cmd(command, *attributes)
			Teamspeak.cmd(:use, id)
			Teamspeak.cmd(command, attributes[0])
		end
		
		def clients
			@clients ||= cmd(:clientlist)

			# because clientlist should only be called on the Server class, we can assign the server dependency here as well
			@clients.each{|c| c.server = self}

			return @clients
		end

		class << self
			def find(*args)
				puts "Server FIND: #{args.inspect}"
			
				if args.first.is_a?(Integer)
					if Teamspeak.servers[args.first]
						return new(Teamspeak.servers[args.first])
					end
				else
					# find by conditions eh
				end
			end
		end
	end

	# mattr_accessor :config
	def self.config
		@config ||= {}
	end

	def self.config=(cfg = {})
		@config = cfg
	end

	def self.history
		@history ||= []
	end
	
	# def self.history=(command)
	# 	@history << command
	# end

	class << self
		def connected?
			@socket ? true : false
		end

		def connect
			@socket = TCPSocket.new(config[:host], 10011)
			ret = @socket.gets # "TS3"
			cmd(:login, :user => config[:user], :password => config[:password])
		end

		def socket
			connect if !connected?
			@socket
		end

		def gm(msg = '')
			cmd(:gm, :msg => msg)
		end

		def cmd(command, *attributes)
			connect if !connected?

			puts attributes.inspect
			attributes = attributes[0] || []
		
			case command
				when :use
					vid = attributes.first.to_i
					if @current_vid && @current_vid == vid
						puts "use(): current_vid == vid (#{vid}) - bailing"
						return false
					else
						puts "selecting new vid: #{vid}"
					end

					_attributes = vid
				when :login
					_attributes = "#{attributes[:user]} #{attributes[:password]}"
				when :gm
					msg = attributes[:msg].gsub(' ', '\s')
					_attributes = "msg=#{msg}"
				else
					attribute_string = attributes.collect{|a,v| "#{a}=#{v}"}.join(' ')
					_attributes = attributes.any? ? attribute_string : ''
			end

			command_string = !_attributes.to_s.empty? ? "#{command} #{_attributes}" : command

			puts "cmd: #{command_string}"
			socket.puts command_string

			eof = false
			data = ''
			begin
				ret = socket.gets
				puts "RAW: #{ret.inspect}"
				rargs = ret.split(' ')
		
				case rargs[0]
				when 'error'
					error = ret.scan(/error id=(\d+) msg=(.*)/)[0]
					error_id = error[0]
					error_msg = error[1]
			
					puts "err: #{error_id} (#{error_msg})"
					eof = true
					
					history << command
				else
					data += ret
				end
			end while !eof

			case command
				when :clientlist
					clientlist = data.split('|').map{|client| 
						clientdata = _to_hash(client, 'client_')
						clientdata[:vid] = @current_vid
						Client.new(clientdata)
					}
					return clientlist
				when :serverlist
					serverlist = data.split("\n").map{|server|
						serverdata = _to_hash(server, 'virtualserver_')
						Server.new(serverdata)
					}
				else
					return data
			end
		end

		def _to_hash(data, strip_key = '')
			data.split(' ').collect{|c| c.split('=')}.inject({}) {|h, el| h[el[0].to_s.gsub(strip_key, '').to_sym] = el[1]; h}
		end

		def servers
			@servers ||= cmd(:serverlist)
			return @servers
		end

	end
end



